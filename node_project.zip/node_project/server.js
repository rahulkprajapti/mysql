//importing modules
const express= require("express");
const fileUpload = require('express-fileupload');
const bodyparser= require("body-parser");

//create app instance
const app=express();

app.use(bodyparser.json());

//front-end not sending any form data
app.use(bodyparser.urlencoded({extended:false}));

const newuser = require("./users/new_user");
app.use("/users",newuser);

//update user details
const update_user= require("./users/update_user");
app.use("/update_details",update_user);

// delete users
const delete_user=require("./users/delete_user");
app.use("/delete_user",delete_user);

// get all users
const get_allusers=require("./users/fetch_allusers");
app.use("/all_users",get_allusers);

// to upload file
app.post('/upload', function(req, res, next) {
    const file = req.files.avtar;
    file.mv("/upload"+file.name, function (err, result){
        if(err){
            res.json({
                message: 'Unable to upload file' + err,
                http_code: 400,
                status: 'failed',
            });
        } else {
            res.json({
                message: 'file uploaded sucessfully',
                http_code: 200,
                status: 'success',
                });
            res.end();
        }
    })
})
    

//Assign port number
app.listen(3000);
console.log("server is listening at port no: 3000");