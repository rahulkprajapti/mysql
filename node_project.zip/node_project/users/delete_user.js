//import express module
const express = require("express");
const nanoid = require('nanoid')
const sha256 = require('sha256');

//import connection moule
const con= require("../config/db_connection");
//create the module(Router)
const router = express.Router();
router.delete("/",async function(req,res) {
    //reading the parameters from client
      try {
      con.query("SELECT COUNT(id) AS usercount FROM users WHERE email_address ='" + req.body.email_address + "'", function (err, result) {
        if (err) {
            console.log("error while inserting the object!");
            res.json({
                message: 'Unable to connect with database ' + err,
                http_code: 400,
                status: 'failed',
            });
            res.end();
            return;
        }
        else {
            if(result[0].usercount === 0){
                res.json({
                    message: 'User does not exist ',
                    http_code: 409,
                    status: 'failed',
                });
                res.end();
                return;
            } else {
                const email_address = req.body.email_address;
              con.query("DELETE FROM users where email_address =?", [email_address], (err) => {
                if (err) {
                  console.log("error: ", err);
                  res.json({
                    message: 'Unable to connect with database ' + err,
                    http_code: 400,
                    status: failed,
                    });
                  res.end();
                  return;
                } else {
                  res.json({
                    message: 'User deleted successfully',
                    http_code: 200,
                    status: 'success',
                    });
                    res.end();
                    return;
                }
              });
          }
        }
    });
      } catch (exp) {
        throw exp;
      }

});
//export router
module.exports=router;