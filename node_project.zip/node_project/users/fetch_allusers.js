//import express module
const express = require("express");
const nanoid = require('nanoid')
const sha256 = require('sha256');
const isEmpty = require('lodash/isEmpty');

//import connection moule
const con= require("../config/db_connection");
//create the module(Router)
const router = express.Router();
router.get("/",async function(req,res) {
    //reading the parameters from client
      try {
      con.query('SELECT email_address AS email_address, first_name AS first_name, last_name AS last_name, country_code AS country_code, contact_no AS contact_no FROM users WHERE is_active = true', function (err, result) {
        if (err) {
            console.log("error while inserting the object!");
            res.json({
                message: 'Unable to connect with database ' + err,
                http_code: 400,
                status: 'failed',
            });
            res.end();
            return;
        }
        else {
            if(isEmpty(result)){
                res.json({
                    message: 'No record found. ',
                    http_code: 200,
                    status: 'success',
                });
                res.end();
                return;
            } else {
                res.json({ 
                    data: result,
                    message: 'get all user details successfully',
                    http_code: 200,
                    status: 'success'
                });
            }
        }
    });
      } catch (exp) {
        throw exp;
      }

});
//export router
module.exports=router;