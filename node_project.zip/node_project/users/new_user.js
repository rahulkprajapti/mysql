//import express module
const express = require("express");
const nanoid = require('nanoid')
const sha256 = require('sha256');

//import connection moule
const con= require("../config/db_connection");
//create the module(Router)
const router = express.Router();
router.post("/",async function(req,res) {
    //reading the parameters from client
      try {
      con.query("SELECT COUNT(id) AS usercount FROM users WHERE email_address ='" + req.body.email_address + "'", function (err, result) {
        if (err) {
            console.log("error while inserting the object!");
            res.json({
                message: 'Unable to connect with database ' + err,
                http_code: 400,
                status: 'failed',
            });
            res.end();
            return;
        }
        else {
            if(result[0].usercount !== 0){
                res.json({
                    message: 'User is already exist ',
                    http_code: 409,
                    status: 'failed',
                });
                res.end();
                return;
            } else {
              const user_id= nanoid() 
              const newUser = {
                email_address: req.body.email_address,
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                country_code: req.body.country_code,
                contact_no: req.body.contact_no,
                password: sha256(req.body.password),
                user_id: user_id,
              };
              con.query("INSERT INTO users SET ?", newUser, (err) => {
                if (err) {
                  console.log("error: ", err);
                  res.json({
                    message: 'Unable to connect with database ' + err,
                    http_code: 400,
                    status: failed,
                    });
                  res.end();
                  return;
                } else {
                  res.json({
                    message: 'User create successfully',
                    http_code: 200,
                    status: 'success',
                    user_id: user_id,
                    });
                    res.end();
                    return;
                }
              });
          }
        }
    });
      } catch (exp) {
        throw exp;
      }

});
//export router
module.exports=router;