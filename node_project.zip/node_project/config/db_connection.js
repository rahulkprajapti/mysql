// MySql Connection String
const mysql = require('mysql');

//local mysql db connection
const connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'interview_db'
});

connection.connect(function(err) {
    // if (err) throw err;
    if(err){
        console.log('error: ', err);
    } else {
        console.log('connection Established !');
    }
});

module.exports = connection;